#pragma once

void initMDNS();
